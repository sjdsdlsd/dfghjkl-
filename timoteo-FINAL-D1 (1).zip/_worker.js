// TIMOTEO AI — Cloudflare Pages Function (API)
// Binding required: KV namespace -> TIMOTEO_KV
// Optional env: ADMIN_PASSWORD (default: admin123 — CHANGE IT!)

const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }
});
const uid = (p = "") => p + [...crypto.getRandomValues(new Uint8Array(10))].map(b => b.toString(16).padStart(2, "0")).join("");
async function sha(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
}
async function getJSON(kv, key, fallback) { try { const v = await kv.get(key, "json"); return v ?? fallback; } catch { return fallback; } }
async function putJSON(kv, key, val) { await kv.put(key, JSON.stringify(val)); }


// D1-backed store with the same interface as KV (used when env.DB is bound instead of KV)
let __schemaReady = false;
class D1Store {
  constructor(db) { this.db = db; }
  async init() {
    if (__schemaReady) return;
    await this.db.prepare("CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT)").run();
    __schemaReady = true;
  }
  async get(key, type) {
    await this.init();
    const row = await this.db.prepare("SELECT value FROM kv WHERE key = ?").bind(key).first();
    if (!row) return null;
    return type === "json" ? JSON.parse(row.value) : row.value;
  }
  async put(key, value) {
    await this.init();
    await this.db.prepare("INSERT INTO kv (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value").bind(key, String(value)).run();
  }
  async delete(key) {
    await this.init();
    await this.db.prepare("DELETE FROM kv WHERE key = ?").bind(key).run();
  }
}

async function authUser(kv, req) {
  const token = (req.headers.get("Authorization") || "").replace("Bearer ", "");
  if (!token) return null;
  return await getJSON(kv, "session:" + token, null);
}
async function authAdmin(kv, req) {
  const token = req.headers.get("X-Admin-Token") || "";
  if (!token) return false;
  return !!(await kv.get("adminsession:" + token));
}

async function handleApi(request, env) {
  let kv = env.TIMOTEO_KV;
  if (!kv && env.DB) kv = new D1Store(env.DB);
  const url = new URL(request.url);
  const path = url.pathname.replace(/^\/api\/?/, "");
  const method = request.method;
  let body = {};
  if (["POST", "PATCH", "PUT"].includes(method)) { try { body = await request.json(); } catch { body = {}; } }

  if (path === "health") return json({ ok: true, kv: !!kv, mode: kv ? "server" : "no-kv" });
  if (!kv) return json({ error: "KV не подключён. Привяжите KV Namespace с именем TIMOTEO_KV в настройках Pages.", code: "NO_KV" }, 503);

  try {
    // ---------- AUTH ----------
    if (path === "auth/register" && method === "POST") {
      const username = String(body.username || "").trim();
      const password = String(body.password || "");
      if (username.length < 2 || username.length > 24) return json({ error: "Имя: от 2 до 24 символов" }, 400);
      if (password.length < 4) return json({ error: "Пароль: минимум 4 символа" }, 400);
      const key = "user:" + username.toLowerCase();
      if (await kv.get(key)) return json({ error: "Пользователь с таким именем уже существует. Войдите или выберите другое имя." }, 409);
      const salt = uid("s_");
      const user = { id: uid("u_"), username, salt, passHash: await sha(salt + ":" + password), createdAt: Date.now() };
      await putJSON(kv, key, user);
      await putJSON(kv, "userById:" + user.id, { id: user.id, username });
      const users = await getJSON(kv, "index:users", []); users.push(user.id); await putJSON(kv, "index:users", users);
      const token = uid("t_"); await putJSON(kv, "session:" + token, { id: user.id, username });
      return json({ token, user: { id: user.id, username } });
    }
    if (path === "auth/login" && method === "POST") {
      const username = String(body.username || "").trim();
      const password = String(body.password || "");
      const user = await getJSON(kv, "user:" + username.toLowerCase(), null);
      if (!user || user.passHash !== await sha(user.salt + ":" + password)) return json({ error: "Неверное имя или пароль" }, 401);
      const token = uid("t_"); await putJSON(kv, "session:" + token, { id: user.id, username: user.username });
      return json({ token, user: { id: user.id, username: user.username } });
    }
    if (path === "admin/login" && method === "POST") {
      const expected = env.ADMIN_PASSWORD || "admin123";
      if (String(body.password || "") !== expected) return json({ error: "Неверный пароль администратора" }, 401);
      const token = uid("a_"); await kv.put("adminsession:" + token, "1");
      return json({ token, defaultPassword: !env.ADMIN_PASSWORD });
    }

    // ---------- ADMIN ----------
    if (path.startsWith("admin/")) {
      if (!await authAdmin(kv, request)) return json({ error: "Нет доступа администратора" }, 401);
      if (path === "admin/overview" && method === "GET") {
        const chatIds = await getJSON(kv, "index:chats", []);
        const chats = [];
        for (const id of chatIds) { const c = await getJSON(kv, "chat:" + id, null); if (c) chats.push(c); }
        chats.sort((a, b) => b.updatedAt - a.updatedAt);
        const userIds = await getJSON(kv, "index:users", []);
        const users = [];
        for (const id of userIds) { const u = await getJSON(kv, "userById:" + id, null); if (u) users.push(u); }
        return json({ chats, users, stats: { users: users.length, chats: chats.length, waiting: chats.filter(c => c.lastRole === "user").length } });
      }
      const m = path.match(/^admin\/chats\/([^/]+)(?:\/(reply))?$/);
      if (m) {
        const chat = await getJSON(kv, "chat:" + m[1], null);
        if (!chat) return json({ error: "Чат не найден" }, 404);
        if (method === "GET") return json({ chat, messages: await getJSON(kv, "msg:" + m[1], []) });
        if (method === "DELETE") {
          await kv.delete("chat:" + m[1]); await kv.delete("msg:" + m[1]);
          let ids = await getJSON(kv, "index:chats", []); await putJSON(kv, "index:chats", ids.filter(x => x !== m[1]));
          return json({ ok: true });
        }
        if (method === "POST" && m[2] === "reply") {
          const text = String(body.text || "").trim();
          if (!text) return json({ error: "Пустое сообщение" }, 400);
          const msgs = await getJSON(kv, "msg:" + m[1], []);
          const msg = { id: uid("m_"), role: "assistant", text, model: chat.model, createdAt: Date.now() };
          msgs.push(msg); await putJSON(kv, "msg:" + m[1], msgs);
          Object.assign(chat, { updatedAt: Date.now(), lastMessage: text.slice(0, 120), lastRole: "assistant" });
          await putJSON(kv, "chat:" + m[1], chat);
          return json({ message: msg });
        }
      }
      return json({ error: "Неизвестный запрос" }, 404);
    }

    // ---------- USER ----------
    const me = await authUser(kv, request);
    if (!me) return json({ error: "Требуется вход" }, 401);
    if (path === "me" && method === "GET") return json({ user: me });

    if (path === "chats" && method === "GET") {
      const ids = await getJSON(kv, "index:chats", []);
      const chats = [];
      for (const id of ids) { const c = await getJSON(kv, "chat:" + id, null); if (c && c.userId === me.id) chats.push(c); }
      chats.sort((a, b) => b.updatedAt - a.updatedAt);
      return json({ chats });
    }
    if (path === "chats" && method === "POST") {
      const chat = {
        id: uid("c_"), userId: me.id, username: me.username,
        title: String(body.title || "Новый диалог").slice(0, 80),
        model: body.model || "ТИМОТЕО Fast",
        systemPrompt: String(body.systemPrompt || ""), temperature: Number(body.temperature ?? 0.7),
        createdAt: Date.now(), updatedAt: Date.now(), lastMessage: "", lastRole: ""
      };
      await putJSON(kv, "chat:" + chat.id, chat); await putJSON(kv, "msg:" + chat.id, []);
      const ids = await getJSON(kv, "index:chats", []); ids.push(chat.id); await putJSON(kv, "index:chats", ids);
      return json({ chat });
    }
    const cm = path.match(/^chats\/([^/]+)(?:\/(messages))?$/);
    if (cm) {
      const chat = await getJSON(kv, "chat:" + cm[1], null);
      if (!chat || chat.userId !== me.id) return json({ error: "Чат не найден" }, 404);
      if (method === "DELETE") {
        await kv.delete("chat:" + cm[1]); await kv.delete("msg:" + cm[1]);
        let ids = await getJSON(kv, "index:chats", []); await putJSON(kv, "index:chats", ids.filter(x => x !== cm[1]));
        return json({ ok: true });
      }
      if (method === "PATCH") {
        if (body.title) chat.title = String(body.title).slice(0, 80);
        if (body.model) chat.model = String(body.model);
        if (body.systemPrompt !== undefined) chat.systemPrompt = String(body.systemPrompt);
        if (body.temperature !== undefined) chat.temperature = Number(body.temperature);
        chat.updatedAt = Date.now(); await putJSON(kv, "chat:" + cm[1], chat);
        return json({ chat });
      }
      if (method === "GET" && cm[2]) return json({ chat, messages: await getJSON(kv, "msg:" + cm[1], []) });
      if (method === "POST" && cm[2]) {
        const text = String(body.text || "").trim();
        const attachment = body.attachment ? { name: String(body.attachment.name || "файл").slice(0, 120), type: String(body.attachment.type || ""), size: Number(body.attachment.size || 0) } : null;
        if (!text && !attachment) return json({ error: "Пустое сообщение" }, 400);
        const msgs = await getJSON(kv, "msg:" + cm[1], []);
        const msg = { id: uid("m_"), role: "user", text, attachment, createdAt: Date.now() };
        msgs.push(msg); await putJSON(kv, "msg:" + cm[1], msgs);
        if (chat.title === "Новый диалог" && text) chat.title = text.slice(0, 42);
        Object.assign(chat, { updatedAt: Date.now(), lastMessage: (text || ("📎 " + attachment.name)).slice(0, 120), lastRole: "user" });
        await putJSON(kv, "chat:" + cm[1], chat);
        return json({ message: msg });
      }
      if (method === "GET") return json({ chat });
    }
    return json({ error: "Неизвестный запрос" }, 404);
  } catch (e) {
    return json({ error: "Ошибка сервера: " + (e.message || e) }, 500);
  }
}


export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api/")) return handleApi(request, env);
    // Otherwise serve static assets (index.html, admin.html, ...)
    if (env.ASSETS) return env.ASSETS.fetch(request);
    return new Response("Not found", { status: 404 });
  }
};
